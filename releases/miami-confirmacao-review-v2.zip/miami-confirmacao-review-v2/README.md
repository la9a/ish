# Miami — referência de revisão V2

Material de revisão, sem implantação. Leia AUDITORIA_VPS.md e PROMPT_LOVABLE.txt.
O server.mjs é a referência do repositório; a VPS possui personalizações que precisam ser preservadas. Não substituir seu arquivo inteiro e não aplicar os patches do repositório contra uma base diferente.

Validação offline da referência (sem instalar dependências ou iniciar o agente):

    node --check src/server.mjs
    node --test src/opening-update.test.mjs src/admin-update.test.mjs src/job-lifecycle.test.mjs
    python3 -m unittest discover -s test -p 'test_*.py' -v

server.patch: referência completa desde a base do repositório indicada no manifesto.
server-lifecycle-reference.patch: somente esta revisão desde o commit anterior de referência.
MANIFEST.json: hashes, bases e resultados. Não há credenciais, sessões ou logs brutos neste pacote.

O arquivo enviado pelo operador, de hash 6990ee51…d22, ainda falha nos quatro testes adicionais executados. O código deste pacote corrige os trechos compartilhados. Os caminhos específicos da VPS com sondas e segunda conexão exigem adaptação e testes antes da troca. O fallback da VPS deve preservar seus 300 ms nessa adaptação.
