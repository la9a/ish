const known = new Set(
  [
    "hero",
    "connect",
    "monitor",
    "register",
    "code",
    "note",
    "code-sending",
    "code-failure",
    "edit-client",
    "reconnect",
    "add-group",
    "edit-draft",
    "single",
    "single-select",
    "multi",
    "multi-select",
    "registration-help",
    "login",
  ].map((stem) => `/art/cat-${stem}.svg`),
);

const completeCharacters: Record<string, string> = {
  "/art/cat-connect.svg": "/art/cat-connect-two-servers.png",
  "/art/cat-code-sending.svg": "/art/cat-code-sending-subject.png",
  "/art/cat-code-failure.svg": "/art/code-failure-paper-plane.png",
  "/art/cat-multi.svg": "/art/cat-multi-natural.png",
  "/art/cat-multi-select.svg": "/art/cat-multi-select-four-paws.png",
};

/** Backgrounds fill the card; characters extend slightly below its clipped lower edge. */
export function BannerArtwork({
  image,
  className,
  priority = false,
}: {
  image: string;
  className: string;
  priority?: boolean;
}) {
  const layered = known.has(image);
  const complete = Boolean(completeCharacters[image]);
  const subject = completeCharacters[image] ?? image.replace(".svg", "-subject.svg");
  return (
    <span
      className={`${className} sb-art-scene`}
      data-artwork={image.replace("/art/cat-", "").replace(".svg", "")}
      data-complete-character={complete || undefined}
      aria-hidden="true"
    >
      <img
        className="sb-art-background"
        src={layered ? image.replace(".svg", "-background.svg") : image}
        alt=""
        fetchPriority={priority ? "high" : "auto"}
      />
      {layered && (
        <img
          className="sb-art-subject"
          data-cat-subject=""
          src={subject}
          alt=""
          fetchPriority={priority ? "high" : "auto"}
        />
      )}
    </span>
  );
}
