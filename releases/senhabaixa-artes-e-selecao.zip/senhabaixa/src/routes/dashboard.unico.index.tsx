import { createFileRoute } from "@tanstack/react-router";
import { ClientDirectory } from "@/components/ClientDirectory";
import { AdminLayout } from "./admin";

export const Route = createFileRoute("/dashboard/unico/")({
  head: () => ({
    meta: [
      { title: "Atendimento único | Senha Baixa" },
      {
        name: "description",
        content: "Escolha uma cliente para abrir o monitoramento individual.",
      },
    ],
  }),
  component: () => <AdminLayout content={<ClientDirectory mode="single" />} />,
});
