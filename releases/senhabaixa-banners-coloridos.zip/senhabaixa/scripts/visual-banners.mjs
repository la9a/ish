// Optional browser check. Run against Vite with the visual-only Supabase env in docs/VALIDATION.md.
// Every Telegram/agent operation and Supabase request is replaced in this browser context only.
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright");
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const output = process.env.SCREENSHOT_DIR || path.join(root, "docs/preview");
await fs.mkdir(output, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const context = await browser.newContext({ viewport: { width: 1440, height: 1050 } });
const uid = "00000000-0000-4000-8000-000000000001";
const user = {
  id: uid,
  aud: "authenticated",
  role: "authenticated",
  email: "demo@app.local",
  app_metadata: { provider: "email" },
  user_metadata: {},
  created_at: new Date().toISOString(),
};
const enc = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
const token = `${enc({ alg: "HS256", typ: "JWT" })}.${enc({ sub: uid, email: user.email, role: "authenticated", aud: "authenticated", exp: Math.floor(Date.now() / 1000) + 3600 })}.visual-test-only`;
const session = {
  access_token: token,
  refresh_token: "visual-test-only",
  expires_at: Math.floor(Date.now() / 1000) + 3600,
  expires_in: 3600,
  token_type: "bearer",
  user,
};
const revisionMode = process.env.SMOKE_REVISION_ONLY === "1";
const clients = [
  {
    id: "visual-lola",
    title: revisionMode ? "Ana Carolina de Oliveira Santos do Nascimento Albuquerque" : "Lola",
    has_session: true,
    pinned: true,
    schedule_env: "17:59:36",
    phone: "+5511999990001",
    created_at: new Date().toISOString(),
    user_id: uid,
  },
  {
    id: "visual-luiz",
    title: revisionMode
      ? "MariaEduardaAparecidaDeSouzaAlbuquerqueSilvaFernandes"
      : "Maria Eduarda de Albuquerque Santos",
    has_session: true,
    phone: "+5511999990002",
    created_at: new Date().toISOString(),
    user_id: uid,
  },
  {
    id: "visual-maria",
    title: "Maria",
    has_session: false,
    phone: "+5511999990003",
    created_at: new Date().toISOString(),
    user_id: uid,
  },
];
const groups = clients.slice(0, 2).map((c, i) => ({
  id: `visual-group-${i}`,
  client_id: c.id,
  user_id: uid,
  name: `Grupo de visitas ${i + 1}`,
  input: `visual-group-${i}`,
  message: `${c.title} x João Raio 5 Cela 2`,
  active: true,
  added_at: new Date().toISOString(),
}));
await context.addInitScript(
  ({ session, uid, clients, groups }) => {
    localStorage.setItem("sb-visual-test-auth-token", JSON.stringify(session));
    localStorage.setItem("app_user_v3", "demo");
    localStorage.setItem("app_user_id_v3", uid);
    localStorage.setItem(
      `tg_cloud_v1:${uid}:clients_index_v1`,
      JSON.stringify(
        clients.map((c) => ({
          ...c,
          hasSession: c.has_session,
          createdAt: Date.now(),
          scheduleEnv: c.schedule_env,
        })),
      ),
    );
    for (const c of clients) {
      localStorage.setItem(
        `tg_cloud_v1:${uid}:client:${c.id}:creds`,
        JSON.stringify({
          apiId: c.id === "visual-luiz" ? 654321 : 123456,
          apiHash: c.id === "visual-luiz" ? "visual-fixture-luiz-only" : "visual-fixture-only",
        }),
      );
      if (c.has_session) {
        localStorage.setItem(
          `tg_cloud_v1:${uid}:client:${c.id}:session`,
          JSON.stringify("visual-fixture-session-only"),
        );
      } else {
        localStorage.removeItem(`tg_cloud_v1:${uid}:client:${c.id}:session`);
      }
      localStorage.setItem(
        `tg_cloud_v1:${uid}:client:${c.id}:groups`,
        JSON.stringify(
          groups.filter((g) => g.client_id === c.id).map((g) => ({ ...g, addedAt: Date.now() })),
        ),
      );
    }
  },
  { session, uid, clients, groups },
);
const logFixture = `[{id:'visual-1',ts:Date.now()-4000,level:'success',msg:'Lola: conta conectada'},{id:'visual-2',ts:Date.now()-2000,level:'info',msg:'Grupo de visitas 1: aguardando abertura'},{id:'visual-pending',ts:Date.now()-1500,level:'success',msg:'Rascunho enviado (Senha: …)',pending:true},{id:'visual-confirmed',ts:Date.now()-1000,level:'success',msg:'Rascunho enviado (Senha: 3)',pending:false},{id:'visual-unknown',ts:Date.now()-500,level:'warn',msg:'Rascunho enviado (Senha: não encontrada)',pending:false}]`;
const monitorStub = `let running=false; const listeners=new Set(); let logs=${logFixture}; const emit=()=>listeners.forEach(fn=>fn(logs,running,{},[])); window.__visualEmitLog=()=>{logs=[...logs,{id:"visual-live",ts:Date.now(),level:"info",msg:"Atualização visual recebida"}];emit()}; export const monitor={subscribe(fn){listeners.add(fn);fn(logs,running,{},[]);return()=>listeners.delete(fn)},resetPrewarm(){},clearLogs(){},clearSends(){},async prewarm(){return true},start(){running=true;emit()},stop(){running=false;emit()},isRunning(){return running}};`;
const noopNames = [
  ...(await fs.readFile(path.join(root, "src/lib/telegram.ts"), "utf8")).matchAll(
    /^export (?:async )?function (\w+)/gm,
  ),
].map((m) => m[1]);
const telegramStub =
  monitorStub +
  noopNames
    .filter((name) => !["signIn", "listGroups"].includes(name))
    .map(
      (name) =>
        `export const ${name}=async()=>${name === "isAuthorized" ? "true" : name === "checkSessionHealth" ? "'alive'" : ["checkAllSessions", "pruneMissingGroups", "listGroups"].includes(name) ? "[]" : name === "loadGroupPhotoById" ? "null" : name === "sendCode" ? "({phoneCodeHash:'visual-code-hash'})" : "undefined"};`,
    )
    .join("\n") +
  `export const signIn=async(opts)=>{if(!opts.password)throw Object.assign(new Error('visual-2fa'),{code:'2FA_REQUIRED'});};export const listGroups=async(id)=>[{id:(id||'active')+'-destination',name:'Destino '+(id||'active'),archived:false}];`;
const multiStub = `let running=false;const listeners=new Set();let logs=${logFixture};const state=()=>({running,logs,statusByClient:{}});const emit=()=>listeners.forEach(f=>f(state()));window.__visualEmitLog=()=>{logs=[...logs,{id:"visual-live",ts:Date.now(),level:"info",msg:"Atualização visual recebida"}];emit()};export const multiMonitor={subscribe(f){listeners.add(f);f(state());return()=>listeners.delete(f)},resetPrewarm(){},clearLogs(){},clearSends(){},async prewarm(){return true},start(){running=true;emit()},stop(){running=false;emit()},allDone(){return false}};`;
const agents = [
  ...(await fs.readFile(path.join(root, "src/lib/miamiAgent.functions.ts"), "utf8")).matchAll(
    /^export const (\w+)/gm,
  ),
].map((m) => m[1]);
const agentStub = agents
  .map(
    (name) =>
      `export const ${name}=async()=>{${["miamiRegisterAccount", "miamiStartJob", "miamiStopJob", "miamiSendCode", "miamiResendCode", "miamiSignIn", "miamiPruneAccounts"].includes(name) ? "window.__visualEngineWrites=(window.__visualEngineWrites||0)+1;" : ""}return (${name === "miamiAccountInfo" ? "{ok:true,active:true,accountDc:1,groups:{}}" : name === "miamiActiveAccounts" ? "{ok:true,ids:['visual-lola','visual-luiz']}" : "{ok:true}"})};`,
  )
  .join("\n");
const cryptoStub = `export const pullAllClientSecrets=async()=>({});export const pullClientSecrets=async()=>({});export const pushClientSecrets=async()=>({ok:true});`;
const myTelegramStub = `export const mtSendPassword=async()=>{window.__visualCodeRequests=(window.__visualCodeRequests||0)+1;if(window.__visualCodeDeferred)return new Promise(resolve=>{window.__visualReleaseCode=()=>resolve(window.__visualCodeFail?{error:'fixture-failure'}:{randomHash:'visual-random-hash'})});return {randomHash:'visual-random-hash'}};export const mtLogin=async()=>({ok:true,session:'visual-only'});export const mtEnsureApp=async()=>({apiId:'123456',apiHash:'visual-fixture-only'});export const mtDiagnose=async()=>({ok:true});`;

const blocked = [];
await context.route("**/*", async (route) => {
  const url = new URL(route.request().url());
  const modules = {
    "/src/lib/telegram.ts": telegramStub,
    "/src/lib/multiMonitor.ts": multiStub,
    "/src/lib/miamiAgent.functions.ts": agentStub,
    "/src/lib/sessionCrypto.functions.ts": cryptoStub,
    "/src/lib/myTelegram.functions.ts": myTelegramStub,
    "/src/lib/serverTime.functions.ts": `export const getServerNow=async()=>({now:Date.UTC(2026,10,5,20,59,0)});`,
  };
  if (modules[url.pathname])
    return route.fulfill({ contentType: "text/javascript", body: modules[url.pathname] });
  if (url.hostname === "visual-test.supabase.co") {
    const headers = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Methods": "GET,POST,DELETE,PATCH,OPTIONS",
    };
    if (route.request().method() === "OPTIONS") return route.fulfill({ status: 204, headers });
    let data = url.pathname.endsWith("/user")
      ? user
      : url.pathname.includes("/clients")
        ? clients
        : url.pathname.includes("/monitored_groups")
          ? groups.filter(
              (g) =>
                !url.searchParams.get("client_id") ||
                url.searchParams.get("client_id") === `eq.${g.client_id}`,
            )
          : url.pathname.includes("/monitor_settings")
            ? null
            : [];
    return route.fulfill({
      status: 200,
      contentType: "application/json",
      headers,
      body: JSON.stringify(data),
    });
  }
  if (url.hostname === "127.0.0.1" && url.port === "3001") return route.continue();
  blocked.push(url.hostname);
  return route.abort();
});
const page = await context.newPage();
page.setDefaultTimeout(20000);
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const base = "http://127.0.0.1:3001";
async function capture(name) {
  if (
    await page
      .getByLabel("Horário de Brasília sincronizado com o servidor", { exact: true })
      .count()
  ) {
    await page.waitForFunction(() => {
      const clock = document.querySelector(
        '[aria-label="Horário de Brasília sincronizado com o servidor"]',
      );
      return clock && !clock.textContent.includes("--");
    });
  }
  await page.waitForFunction(() =>
    [...document.querySelectorAll(".sb-art-scene img")].every(
      (img) => img.complete && img.naturalWidth > 0,
    ),
  );
  await page.waitForFunction(() =>
    [...document.querySelectorAll('[role="listbox"], [role="dialog"]')].every(
      (el) => getComputedStyle(el).opacity === "1",
    ),
  );
  await page.screenshot({
    path: path.join(output, `${name}.png`),
    fullPage: true,
    animations: "disabled",
  });
  assert.equal(
    await page.evaluate(() => document.documentElement.scrollWidth > innerWidth),
    false,
    `${name}: overflow`,
  );
}
const geometry = [];
const interactions = [];
async function recordFrame(name, selector = ".sb-hero, .sb-page-banner") {
  await page.locator(selector).first().waitFor();
  await page.waitForFunction(() =>
    [...document.querySelectorAll(".sb-art-scene img")].every(
      (img) => img.complete && img.naturalWidth > 0,
    ),
  );
  const frame = page.locator(selector).first();
  await frame.evaluate(async (element) => {
    const animations = new Set(element.getAnimations({ subtree: true }));
    for (let ancestor = element.parentElement; ancestor; ancestor = ancestor.parentElement)
      for (const animation of ancestor.getAnimations()) animations.add(animation);
    await Promise.all(
      [...animations]
        .filter((animation) => Number.isFinite(animation.effect?.getTiming().iterations ?? 1))
        .map((animation) => animation.finished.catch(() => {})),
    );
  });
  const row = await frame.evaluate((element) => {
    const r = element.getBoundingClientRect(),
      css = getComputedStyle(element);
    const scene = element.querySelector(".sb-art-scene"),
      image = element.querySelector("[data-cat-subject]");
    const s = scene?.getBoundingClientRect(),
      i = image?.getBoundingClientRect();
    const style = image && getComputedStyle(image);
    const natural =
      image?.tagName === "IMG" ? { width: image.naturalWidth, height: image.naturalHeight } : null;
    let content =
      image && image.tagName !== "IMG"
        ? {
            left: i.left - r.left,
            top: i.top - r.top,
            right: i.right - r.left,
            bottom: i.bottom - r.top,
          }
        : null;
    if (i && natural && style.objectFit === "contain") {
      const scale = Math.min(i.width / natural.width, i.height / natural.height);
      const width = natural.width * scale,
        height = natural.height * scale;
      const position = style.objectPosition.split(" ");
      const factor = (value) =>
        value === "right" || value === "bottom"
          ? 1
          : value === "center"
            ? 0.5
            : value?.endsWith("%")
              ? parseFloat(value) / 100
              : 0;
      const left = i.left + (i.width - width) * factor(position[0]),
        top = i.top + (i.height - height) * factor(position[1]);
      content = {
        left: left - r.left,
        top: top - r.top,
        right: left + width - r.left,
        bottom: top + height - r.top,
      };
    }
    return {
      width: r.width,
      height: r.height,
      x: r.left,
      radius: css.borderRadius,
      scene: s && { width: s.width, height: s.height },
      stem: scene?.dataset.artwork,
      completeCharacter: scene?.hasAttribute("data-complete-character"),
      backgroundSrc: element.querySelector(".sb-art-background")?.currentSrc,
      src: image?.currentSrc || style?.backgroundImage,
      fit: style?.objectFit,
      backgroundPosition: style?.backgroundPosition,
      natural,
      content,
    };
  });
  row.name = name;
  row.viewport = page.viewportSize();
  assert.ok(
    Math.abs(row.height - 360) <= 1,
    `${name}: expected shared360px frame, got${row.height}`,
  );
  if (row.scene)
    assert.ok(
      Math.abs(row.scene.width - row.width) <= 2 && Math.abs(row.scene.height - row.height) <= 2,
      `${name}: art layer must fill frame`,
    );
  if (row.content) {
    assert.ok(
      row.content.left >= -1 &&
        row.content.right <= row.width + 1 &&
        row.content.top >= -1 &&
        row.content.bottom <= row.height + (row.completeCharacter ? 1 : 13),
      `${name}: full characters must fit; cropped torsos may bleed12px below frame`,
    );
  }
  assert.ok(
    row.backgroundSrc?.endsWith(`/art/cat-${row.stem}-background.svg`),
    `${name}: restored pastel background must match its scene`,
  );
  assert.ok(!row.src?.includes("editorial-scenes-"), `${name}: editorial sheets must be absent`);
  geometry.push(row);
  await capture(name);
  return row;
}
async function borderSnapshot(locator) {
  return locator.evaluate((element) => {
    const s = getComputedStyle(element);
    return {
      color: s.borderTopColor,
      width: s.borderTopWidth,
      style: s.borderTopStyle,
      shadow: s.boxShadow,
    };
  });
}
async function hoverAndSelect() {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(base + "/dashboard/unico");
  await page.getByRole("heading", { name: "Atendimento único", exact: true }).waitFor();
  const single = page.locator('[data-selection-item="single"]').first();
  await page.mouse.move(1, 1);
  const beforeSingle = await borderSnapshot(single);
  await single.hover();
  await page.waitForTimeout(180);
  const afterSingle = await borderSnapshot(single);
  assert.deepEqual(
    afterSingle,
    beforeSingle,
    "Single selection must not add a border/ring on hover",
  );
  interactions.push({ case: "single-hover", before: beforeSingle, after: afterSingle });
  await page.goto(base + "/dashboard/multi");
  const cards = page.locator('[data-selection-item="multi"]');
  await cards.first().waitFor();
  await page.mouse.move(1, 1);
  const beforeMulti = await borderSnapshot(cards.first());
  await cards.first().hover();
  await page.waitForTimeout(180);
  const hoveredMulti = await borderSnapshot(cards.first());
  assert.deepEqual(
    hoveredMulti,
    beforeMulti,
    "Multi selection must not add a border/ring on hover",
  );
  const aligned = await cards.evaluateAll((items) =>
    items.map((card) => {
      const input = card.querySelector('input[type="checkbox"]'),
        name = card.querySelector('[data-client-title="available"]');
      const a = input.getBoundingClientRect(),
        b = name.getBoundingClientRect();
      const css = getComputedStyle(name);
      return {
        name: name.textContent,
        delta: Math.abs(a.top + a.height / 2 - (b.top + b.height / 2)),
        lines: b.height / parseFloat(css.lineHeight),
      };
    }),
  );
  assert.ok(
    aligned.some((row) => row.lines >= 1.8),
    "Alignment fixture must include a multi-line name",
  );
  for (const row of aligned)
    assert.ok(row.delta <= 1.5, `Checkbox must align to NAME center (${row.name}): ${row.delta}px`);
  await page.getByRole("checkbox", { name: `Selecionar ${clients[0].title}`, exact: true }).check();
  await page.waitForTimeout(180);
  const selected = await borderSnapshot(cards.first());
  assert.notEqual(selected.color, beforeMulti.color, "Selection keeps its distinct fine border");
  assert.equal(selected.width, "1px");
  await page.mouse.move(1, 1);
  await page.waitForTimeout(180);
  const selectedUnhovered = await borderSnapshot(cards.first());
  assert.deepEqual(selected, selectedUnhovered, "Selected card border remains stable under hover");
  interactions.push({
    case: "multi-hover-and-selection",
    before: beforeMulti,
    hover: hoveredMulti,
    selected,
    aligned,
  });
  await capture("multi-selecao-alinhamento-390");
}
async function connectionsOrder() {
  await page.goto(base + "/admin/connection");
  await page.getByRole("heading", { name: "Conexões", exact: true }).waitFor();
  await page.getByRole("button", { name: `Editar ${clients[0].title}`, exact: true }).waitFor();
  const filter = page.getByRole("combobox", { name: "Filtrar conexões por status", exact: true });
  await filter.click();
  await page.getByRole("option", { name: "Todas as contas", exact: true }).click();
  const names = await page
    .getByRole("region", { name: "Contas e conexões", exact: true })
    .locator("ul > li h3")
    .allTextContents();
  const expected = [
    ...clients.filter((c) => c.has_session).sort((a, b) => a.title.localeCompare(b.title, "pt-BR")),
    ...clients
      .filter((c) => !c.has_session)
      .sort((a, b) => a.title.localeCompare(b.title, "pt-BR")),
  ].map((c) => c.title);
  assert.deepEqual(
    names,
    expected,
    "Saved sessions must precede disconnected clients in All accounts",
  );
  interactions.push({ case: "connections-all-order", names });
  await capture("conexoes-ordenadas-390");
}
async function monitorViews(width) {
  await page.goto(base + "/dashboard/unico/visual-lola");
  await page.getByRole("heading", { name: "Monitoramento", exact: true }).waitFor();
  await recordFrame(`monitor-unico-${width}`);
  const events = page.getByRole("region", {
    name: "Histórico de eventos do atendimento",
    exact: true,
  });
  assert.equal(await events.getByText("Horários de Brasília", { exact: true }).count(), 0);
  if (width < 900) await page.getByRole("tab", { name: /Eventos/ }).click();
  assert.equal(await events.locator("footer").count(), 0, "Empty log footer is omitted");
  await capture(`monitor-sem-rodape-${width}`);
  await page.goto(base + "/dashboard/multi");
  for (const client of clients.slice(0, 2))
    await page.getByRole("checkbox", { name: `Selecionar ${client.title}`, exact: true }).check();
  await page.getByRole("button", { name: /Abrir monitoramento/ }).click();
  await page.getByRole("heading", { name: "Monitoramento", exact: true }).waitFor();
  await recordFrame(`monitor-multi-${width}`);
}
async function headerStates() {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(base + "/dashboard");
  await page.evaluate((uid) => localStorage.removeItem(`tg_cloud_v1:${uid}:wizard_draft_v2`), uid);
  await page.goto(base + "/dashboard/cadastro");
  await page.getByLabel("Nome da cliente", { exact: true }).fill("Cliente visual");
  await page.getByLabel("Telefone", { exact: true }).fill("11988887777");
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Enviar código", exact: true })
    .waitFor();
  await recordFrame("codigo-confirmacao-390", ".sb-flow-header");
  await page.evaluate(() => {
    window.__visualCodeDeferred = true;
    window.__visualCodeFail = true;
  });
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Enviar código", exact: true })
    .click();
  await page.locator('[data-flow-state="sending"]').waitFor();
  await page.getByRole("dialog").getByRole("status").waitFor();
  await page.waitForFunction(() => typeof window.__visualReleaseCode === "function");
  await recordFrame("codigo-enviando-390", ".sb-flow-header");
  await page.evaluate(() => window.__visualReleaseCode());
  await page.locator('[data-flow-state="failure"]').waitFor();
  await page.getByRole("dialog").getByRole("button", { name: "Voltar", exact: true }).waitFor();
  await recordFrame("codigo-falha-390", ".sb-flow-header");
  await page.getByRole("dialog").getByRole("button", { name: "Voltar", exact: true }).click();
  await page.goto(base + "/dashboard/unico/visual-lola");
  await page.getByRole("heading", { name: "Monitoramento", exact: true }).waitFor();
  await page.getByRole("button", { name: "Editar grupos", exact: true }).click();
  await page
    .getByRole("button", { name: "Editar grupo e rascunho de Grupo de visitas 1", exact: true })
    .click();
  await page.getByRole("dialog").waitFor();
  await recordFrame("editar-rascunho-390", ".sb-illustrated-header");
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: /Adicionar grupo/ }).click();
  await page.getByRole("dialog").waitFor();
  await recordFrame("adicionar-grupo-390", ".sb-illustrated-header");
  await page.keyboard.press("Escape");
}
async function loginCheck() {
  const loginContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
  await loginContext.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    if (url.pathname === "/src/lib/accessKey.functions.ts")
      return route.fulfill({
        contentType: "text/javascript",
        body: "export const getAccessLock=async()=>({remainingMs:0,vpn:false});export const loginWithAccessKey=async()=>({ok:false,error:'fixture-only'});",
      });
    if (url.hostname === "127.0.0.1" && url.port === "3001") return route.continue();
    return route.abort();
  });
  const loginPage = await loginContext.newPage();
  loginPage.on("pageerror", (error) => errors.push(error.message));
  for (const size of [
    { width: 390, height: 844 },
    { width: 844, height: 390 },
  ]) {
    await loginPage.setViewportSize(size);
    await loginPage.goto(base + "/login");
    await loginPage.getByLabel("Sua chave de acesso", { exact: true }).waitFor();
    assert.equal(await loginPage.locator(".sb-auth-art").isVisible(), false);
    await loginPage.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
    assert.equal(await loginPage.locator(".sb-auth-art").isVisible(), false);
    const loginGeometry = await loginPage.evaluate(() => ({
      pageHeight: document.documentElement.scrollHeight,
      formBottom: document.querySelector(".sb-auth-form").getBoundingClientRect().bottom + scrollY,
      viewportHeight: innerHeight,
      overflow: document.documentElement.scrollWidth > innerWidth,
    }));
    assert.ok(
      loginGeometry.pageHeight <=
        Math.max(loginGeometry.formBottom, loginGeometry.viewportHeight) + 32,
      "Hidden login art must not reserve a second screen below the form",
    );
    assert.equal(loginGeometry.overflow, false);
    interactions.push({ case: "login-mobile-scroll", width: size.width, ...loginGeometry });
    await loginPage.screenshot({
      path: path.join(output, `login-sem-gato-${size.width}.png`),
      fullPage: true,
      animations: "disabled",
    });
  }
  await loginPage.setViewportSize({ width: 1440, height: 1050 });
  await loginPage.locator(".sb-auth-art").waitFor();
  assert.ok(Math.abs((await loginPage.locator(".sb-auth-art").boundingBox()).height - 360) <= 1);
  await loginPage.screenshot({
    path: path.join(output, "login-desktop-1440.png"),
    fullPage: true,
    animations: "disabled",
  });
  await loginContext.close();
}
try {
  for (const size of [
    { width: 390, height: 844 },
    { width: 844, height: 390 },
    { width: 1440, height: 1050 },
  ]) {
    await page.setViewportSize(size);
    const current = [];
    for (const [route, title, name] of [
      ["/dashboard", /Olá, demo/, "home"],
      ["/dashboard/clientes", "Minhas clientes", "clientes"],
      ["/dashboard/unico", "Atendimento único", "unico"],
      ["/dashboard/multi", "Atendimento multi", "multi"],
      ["/admin/connection", "Conexões", "conexoes"],
      ["/dashboard/cadastro", "Nova cliente", "cadastro"],
    ]) {
      await page.goto(base + route);
      await page
        .getByRole("heading", { name: title, exact: typeof title === "string" })
        .first()
        .waitFor();
      current.push(await recordFrame(`${name}-${size.width}`));
      if (name === "cadastro") await recordFrame(`ajuda-cadastro-${size.width}`, ".sb-cat-callout");
    }
    assert.ok(
      current.every(
        (row) =>
          Math.abs(row.width - current[0].width) <= 1 &&
          Math.abs(row.height - current[0].height) <= 1 &&
          row.radius === current[0].radius,
      ),
      `Main banner geometry must match at${size.width}px`,
    );
    await monitorViews(size.width);
  }
  await hoverAndSelect();
  await connectionsOrder();
  await headerStates();
  await loginCheck();
  assert.deepEqual(errors, []);
  await fs.writeFile(
    path.join(output, "report.json"),
    JSON.stringify({ geometry, interactions, errors }, null, 2),
  );
  console.log(
    `PASS ${geometry.length} banner frames, hover/selection, NAME checkbox alignment, connection order, log footer and mobile login scroll`,
  );
} catch (error) {
  await fs.writeFile(
    path.join(output, "report.json"),
    JSON.stringify({ geometry, interactions, errors, error: String(error) }, null, 2),
  );
  await page.screenshot({ path: path.join(output, "failure.png"), fullPage: true });
  console.log("FAIL", page.url(), String(error));
  throw error;
} finally {
  await browser.close();
}
