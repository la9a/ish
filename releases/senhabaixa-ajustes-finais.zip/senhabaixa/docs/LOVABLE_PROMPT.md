# Prompt para o Lovable — Senha Baixa

Integre o código e as artes do ZIP na versão atual do meu projeto. Preserve dados, segredos, backend e correções funcionais já existentes. Não reconstrua o app nem publique automaticamente.

## Três áreas distintas

Mantenha as três áreas com destinos, títulos, banners e comportamentos próprios:

- **Minhas clientes**: `/dashboard/clientes`. Lista todas as clientes do operador, com busca e filtros. Clicar na cliente expande/recolhe um card com dados reais, horários, grupos e rascunhos. Não ativa uma conta e não abre monitoramento. Editar e reconectar são ações explícitas. Os links “Gerenciar clientes”, “Ver todas” e os atalhos de clientes da home levam para essa área.
- **Atendimento único**: `/dashboard/unico`. Banner e título próprios de atendimento único, com a arte `cat-single-select`. Escolher uma cliente abre `/dashboard/unico/$clientId`, mantendo o fluxo real do monitor individual. O botão de voltar do monitor diz “Atendimento único”.
- **Atendimento multi**: `/dashboard/multi`. Seleção de duas ou mais contas e monitoramento múltiplo existentes, com artes próprias para seleção e operação. Não misture essa seleção com o inventário de clientes. Mostre os **nomes completos** nas contas disponíveis, selecionadas e nos cartões do monitor: sem `truncate`, reticências ou limite de linhas. Quebre nomes longos e mantenha espaço para checkbox/avatar/pin. As duas colunas só aparecem quando o próprio painel tem largura suficiente, não apenas quando a janela é larga.

A sidebar inclui Visão geral, Minhas clientes, Atendimento único, Atendimento multi e Conexões, com seleção ativa coerente. Preserve a marca **Senha Baixa**, sem ponto, o rótulo **Workspace** e a ausência do cartão promocional e dos antigos rodapés.

Integre `ClientDirectory.tsx`, a nova rota `dashboard.clientes.tsx`, os links atualizados e a árvore de rotas gerada pelo TanStack. Não edite `routeTree.gen.ts` manualmente.

## Credenciais e resultados

Nas conexões, cada cliente — com sessão salva ou desconectada — tem o botão **Editar**, que abre uma janela no lugar de navegar para outra tela. Remova os antigos dropdowns/accordions de credenciais de todos os cards. Não restaure `ClientCredentials.tsx`, que foi removido.

Integre `ClientEditDialog.tsx` e `clientEdit.ts`. Dentro da janela, os quatro campos ficam sempre visíveis, com rótulo e valor abaixo, nesta ordem exata: **Nome, Número, API Hash, API ID**. Não use menus ou seções expansíveis. A edição aberta por `/dashboard/cadastro?edit=1` usa o mesmo formulário e a mesma ordem.

Nome e número são dados do cadastro. Em conta com sessão salva, as credenciais reais ficam visíveis para consulta sem trocar o par usado por essa sessão. Em cliente sem sessão salva, o par API pode ser atualizado junto, com validação. Salvar não pode limpar autorização, abrir monitoramento, trocar a conta ativa ou solicitar código automaticamente. Leituras e escritas usam o ID da cliente e o UUID do operador explícitos. Cancelar não grava; mudança de usuário invalida a edição. Não duplique nome/telefone abaixo do formulário nem registre credenciais em logs.

Nos eventos de envio, substitua **somente a reticência de posição pendente** após “Senha:” por um spinner inline acessível, com rótulo “Apurando senha”. Integre `pendingPosition.ts` e `MonitorLog.tsx`. Preserve números reais e mensagens de falha/não confirmação. Não calcule, confirme ou invente posição pelo tempo decorrido. A animação é visual; o motor continua responsável pelo resultado real.

## Entrada suave das páginas

Integre a versão atual de `PageEntrance.tsx` e suas regras CSS. A entrada ocorre **por elementos**, em uma sequência curta de banner, cards e linhas, usando opacidade 0→1 e deslocamento vertical de 8 px. Duração de 320 ms, intervalo de 32 ms e atraso máximo de 180 ms. Não substitua por um único fade quase imperceptível no contêiner da página.

No modo leve de celular (`data-lite`), mantenha uma entrada mais curta: 280 ms, 4 px, intervalo de 24 ms e atraso máximo de 120 ms. Respeite a preferência de movimento reduzido. Os elementos continuam visíveis se a melhoria de animação não rodar.

Anime somente na entrada da rota e na primeira chegada dos elementos durante uma janela curta de carregamento. Não reanime a cada tick do relógio, evento de log, filtro ou interação. Não use `key` para remontar o conteúdo, esperas de navegação ou outra instância de monitoramento. Preserve formulários, grupos, conexões e logs montados.

## Artes e revisão de todos os banners

Use `BannerArtwork.tsx` e os arquivos atuais de `public/art`, inclusive os novos PNGs. O fundo preenche o card inteiro com `cover`; a ilustração principal fica em uma camada independente com `contain`, preservando sua proporção.

Cada função mantém uma arte própria:

| Contexto                          | Arte-base                                            |
| --------------------------------- | ---------------------------------------------------- |
| Início                            | `cat-hero`                                           |
| Login                             | `cat-login`                                          |
| Minhas clientes                   | `cat-note`                                           |
| Seleção de atendimento único      | `cat-single-select`                                  |
| Monitoramento único               | `cat-single`                                         |
| Seleção multi                     | `cat-multi-select`                                   |
| Monitoramento multi               | `cat-multi`                                          |
| Conexões                          | `cat-connect`                                        |
| Nova cliente / edição / reconexão | `cat-register` / `cat-edit-client` / `cat-reconnect` |
| Ajuda do cadastro                 | `cat-registration-help`                              |
| Confirmação / envio               | `cat-code` / `cat-code-sending`                      |
| Falha                             | `code-failure-paper-plane.png`                       |
| Adicionar grupo / editar rascunho | `cat-add-group` / `cat-edit-draft`                   |

Para cada arte-base, use o respectivo `-background.svg`. Preserve o mapa de PNGs da versão atual de `BannerArtwork.tsx`:

- Conexões: `/art/cat-connect-complete-cables.png`.
- Seleção multi: `/art/cat-multi-select-natural.png`.
- Monitoramento multi: `/art/cat-multi-natural.png`.
- Envio: `/art/cat-code-sending-subject.png`.
- Falha: `/art/code-failure-paper-plane.png`, somente o avião amassado, sem gato.

**Substitua as artes antigas de multi**, que tinham corpos prolongados como colunas. As novas mostram gatos inteiros sentados, com cabeças, troncos curtos, patas e caudas em proporções naturais. Não estique a imagem nem prolongue o corpo por CSS/SVG para encostar no banner. Use `contain` e preserve o tamanho relativo dos gatos e objetos.

**Substitua a arte antiga de conexões**, que tinha fios terminando secos no ar. Na nova imagem, o fio roxo sai do conector da pata e chega inteiro a um aparelho; o fio azul chega inteiro a um roteador do outro lado. Todos os trechos e terminações ficam dentro da composição. Não volte ao cabo em U ou ao PNG com fios cortados nas bordas.

As cinco artes PNG completas são exceções à sangria: preserve `data-complete-character` e seus estilos com base a 2 px, para não cortar patas, aparelhos, fios ou avião no chão. Os demais SVGs mantêm seus estilos existentes.

Revise todas as áreas no celular em pé/deitado e no desktop. Orelhas, caudas, objetos e corpos precisam estar coerentes; não basta o elemento `<img>` estar no retângulo. Não use véu branco, máscaras claras, recortes no meio do gato, miniatura com faixa vazia ou distorção. Não volte às antigas cenas inteiras `-wide.svg`/`-portrait.svg` para tentar corrigir o encaixe.

## Requisitos anteriores que permanecem

Mantenha menus customizados Radix e os novos ícones/avatares. Na home, o banner vem primeiro, com VISÃO GERAL, saudação real e botões Gerenciar clientes/Adicionar cliente iguais e empilhados. Sem personalização de perfil ou rodapés antigos.

Preserve o formato 12h/24h local por UUID/dispositivo, o relógio de Brasília sincronizado com o servidor, `scheduleEnv` canônico em 24h e o método `abertura2`. Durações e contagens regressivas não recebem AM/PM.

Mantenha confirmação, solicitação e falha do cadastro no mesmo modal montado, seguindo estados reais e a trava contra solicitações duplicadas. Preserve recuperação de cadastro, credenciais, 2FA e navegação de saída compartilhada.

Mantenha no CSS global:

```css
#lovable-badge {
  display: none !important;
}
```

O aplicativo continua sem Turnstile, preservando validação da chave no servidor, sessão Supabase, limites, bloqueios e guards. Não crie bypass de autenticação. Configurações externas de WAF são separadas do widget do app.

## Integrações e validação

Preserve isolamento por operador/UUID, RLS, filtros `user_id`, sincronização e criptografia de sessões. Não regenere a chave de criptografia nem copie segredos para o ZIP. Logout continua limpando a sessão e recarregando o documento.

Não altere o motor da VPS: URLs/deadlines do agente, locks antes de qualquer `await`, flood deadlines, uma conexão por conta, tratamento de duplicidade e confirmação por update/ACK próprio permanecem. Não faça envios de teste para grupos de clientes durante o redesign.

Execute typecheck, build, testes existentes e os novos testes de apresentação de posição. No smoke visual, use somente fixtures e transporte interceptado. O modo `SMOKE_WORKSPACE_ONLY=1` cobre as três áreas, expansão sem navegar, editor sem dropdowns e com quatro campos ordenados, nomes longos completos, spinner, animação por elementos e movimento reduzido e estados do cadastro.

Confira em 360/390/430/768/844/1440 px, menus e modais abertos, teclado e foco. Valide que abrir Minhas clientes não monta um monitor, que os dois atendimentos continuam operando e que animações não reiniciam conexões. Não declare login ou envio real validado sem credenciais e uma verificação integrada autorizada. Entregue para revisão sem publicar.
