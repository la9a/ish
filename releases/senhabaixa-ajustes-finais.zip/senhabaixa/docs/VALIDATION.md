# Validação da entrega

Revisão de 5 de novembro de 2026. Ambiente: Node 24.22.1 e Bun 1.3.13.

| Verificação                                 | Resultado                                                                                                                                                                                                                                                                                   |
| ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run typecheck`                         | Passou.                                                                                                                                                                                                                                                                                     |
| `npm run build`                             | Passou, cliente e servidor Cloudflare. Permanecem avisos herdados de APIs antigas e tamanho de bundle.                                                                                                                                                                                      |
| `npm run test`                              | **54 testes passaram**: autenticação 9, isolamento/cache 11, relógio 13, edição de cliente 5, posição pendente 3, recuperação do cadastro 10 e ACK do agente 3.                                                                                                                             |
| Editor de clientes                          | Chromium passou com clientes conectadas e desconectadas: janela de edição, quatro campos na ordem Nome/Número/API Hash/API ID, sem accordion nos cards ou formulário. Cancelar não grava; salvar nome/número preserva sessão e API; cliente sem sessão permite atualizar um par API válido. |
| Isolamento e ausência de efeitos colaterais | Leituras/escritas usam cliente e operador explícitos. Verificação cobriu outra cliente, conta ativa, sessão e ausência de pedido de código ou início de jobs ao salvar.                                                                                                                     |
| Nomes completos no multi                    | Passou em disponíveis, selecionadas e cartões do monitor, com nomes muito longos e sobrenome sem espaços. Helper em 320/844/1440 px e smoke final em 390/844/1440 px, sem reticências nem overflow.                                                                                         |
| Entrada dos elementos                       | Browser confirmou alvos distintos com animação de 320 ms e atrasos escalonados de 0/32 ms. Tick do relógio e novo log não repetem a entrada; movimento reduzido não produz animações.                                                                                                       |
| Artes                                       | PNGs novos no multi/seleção, com corpos curtos e patas inteiras. Conexões usa imagem nova com dois fios contínuos entre conectores e aparelhos. A falha permanece somente com avião amassado, sem gato. Imagens carregaram nos cenários responsivos.                                        |
| `git diff --check`                          | Passou.                                                                                                                                                                                                                                                                                     |

O smoke principal desta revisão é `SMOKE_REVISION_ONLY=1`. Ele verifica os comportamentos alterados, em vez de afirmar uma validação integrada da VPS. O editor bloqueia troca das credenciais vinculadas a uma sessão salva; permite atualizar metadados sem apagar a autorização. Em cliente sem sessão, valida o par API antes de salvar. Os valores da cliente seguinte e do operador seguinte não podem servir como fallback.

Os testes existentes de Brasília, formato 12h/24h, posição pendente, recuperação do cadastro e ACK continuam na suíte. Esta revisão não altera o motor de envio.

## Repetir a verificação visual

`scripts/visual-smoke.mjs` exige Playwright e Chromium fora das dependências de produção. Os pedidos do Supabase e os módulos de transporte Telegram/agente são substituídos apenas no navegador do teste. Não existe bypass ou modo demo no aplicativo entregue.

```sh
# Terminal 1, somente para teste visual: valores fictícios.
VITE_SUPABASE_URL=https://visual-test.supabase.co VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_visual_test_only npm run dev -- --host 0.0.0.0 --port 3001

# Terminal 2, cenários desta revisão.
SMOKE_REVISION_ONLY=1 PLAYWRIGHT_MODULE=/workspace/.tools/node_modules/playwright/index.mjs SCREENSHOT_DIR=/tmp/ish-revision npm run test:ui
```

O script também mantém os modos completo, `SMOKE_WORKSPACE_ONLY`, `SMOKE_REFINEMENTS_ONLY` e `SMOKE_REGISTRATION_ONLY` para futuras verificações mais amplas. Em outro ambiente, ajuste `PLAYWRIGHT_MODULE` e `CHROMIUM_PATH`; não copie valores fictícios para produção.

## Limites e distribuição

As capturas de [preview](preview/) usam somente nomes, credenciais e serviços fictícios. Não houve login de produção, edição de dados reais, contas Telegram reais nem envios para grupos. A verificação local não comprova RLS implantada ou disponibilidade da VPS; isso exige homologação autorizada.

O lint global já falhava no ZIP original. Esta entrega não declara lint global limpo; os componentes alterados passaram por TypeScript e lint focado, com avisos herdados de Fast Refresh nos arquivos de rotas.

O ZIP contém fontes e assets atuais, inclusive arquivos novos ainda não versionados, sem dependências, builds ou segredos. O prompt completo está em [LOVABLE_PROMPT.md](LOVABLE_PROMPT.md), e o prompt focado nesta revisão está em [LOVABLE_ACABAMENTOS_FINAIS.md](LOVABLE_ACABAMENTOS_FINAIS.md).

Nada foi publicado nem enviado ao GitHub. Preserve os dados, segredos e a chave de criptografia existentes ao integrar. O app mantém a remoção do Turnstile, autenticação e limites; regras externas de WAF continuam sendo configuração do provedor.
