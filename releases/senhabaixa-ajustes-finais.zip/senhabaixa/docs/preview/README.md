# Telas da revisão

Capturas atuais com nomes, contas, credenciais e transportes fictícios. Não representam contas ou envios reais.

| Área revisada                                        | Desktop                                     | Celular                                                                                     |
| ---------------------------------------------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------- |
| Conexões, sem dropdowns e com cabos completos        | [Ver](conexoes-sem-modal-1440.png)          | [Ver](conexoes-sem-modal-390.png)                                                           |
| Editar cliente conectada, quatro campos ordenados    | [Ver](editar-cliente-conectada-1440.png)    | [Ver](editar-cliente-conectada-390.png) · [Deitado](editar-cliente-conectada-844.png)       |
| Editar cliente desconectada                          | —                                           | [Ver](editar-cliente-desconectada-390.png)                                                  |
| Seleção multi, nomes completos e gatos proporcionais | [Ver](multi-nomes-inteiros-1440.png)        | [Ver](multi-nomes-inteiros-390.png) · [Deitado](multi-nomes-inteiros-844.png)               |
| Monitoramento multi, nomes completos                 | [Ver](multi-monitoramento-natural-1440.png) | [Ver](multi-monitoramento-natural-390.png) · [Deitado](multi-monitoramento-natural-844.png) |
| Preferência de movimento reduzido                    | [Ver](elementos-movimento-reduzido.png)     | —                                                                                           |

Outras áreas preservadas:

- [Minhas clientes](minhas-clientes-390.png)
- [Atendimento único](atendimento-unico-390.png)
- [Visão geral](home-390.png)
- [Envio de código](cadastro-enviando-mobile.png)
- [Falha com apenas avião amassado](cadastro-falha-mobile.png)
- [Formato 12h/24h](horario-opcoes-12h.png)

A animação de entrada foi verificada em execução: alvos distintos, duração de320ms, atrasos escalonados e nenhuma repetição em atualizações do relógio/log. Uma captura estática não representa esse movimento.

[Verificações e limites](../VALIDATION.md)
