Esta galeria mostra a revisão editorial atual com dados e transportes fictícios. O [contato das 18 cenas](colecao-18-artes.png) permite conferir o conjunto, e o [relatório de medidas](report.json) registra a validação dos 32 quadros e interações.

A visão geral está disponível em [desktop](home-1440.png) e [celular](home-390.png). As áreas [Minhas clientes](clientes-390.png), [Atendimento único](unico-390.png), [Atendimento multi](multi-390.png) e [Conexões](conexoes-390.png) usam o mesmo enquadramento. A versão de [Conexões no desktop](conexoes-1440.png) mostra a nova arte de dois cabos completos.

O [monitor individual](monitor-unico-390.png) e o [monitor multi](monitor-multi-390.png) mantêm seus controles. A [seleção e o alinhamento dos checks](multi-selecao-alinhamento-390.png), a [ordem das conexões](conexoes-ordenadas-390.png) e os [eventos sem a frase no rodapé](monitor-sem-rodape-390.png) foram conferidos em execução.

O login fica limpo no [celular em pé](login-sem-gato-390.png) e no [celular deitado](login-sem-gato-844.png), sem arte aparecendo durante a rolagem. A ilustração permanece no [login desktop](login-desktop-1440.png).

Cadastro e modais foram capturados em [nova cliente](cadastro-390.png), [confirmação](codigo-confirmacao-390.png), [envio](codigo-enviando-390.png), [falha com avião amassado](codigo-falha-390.png), [adicionar grupo](adicionar-grupo-390.png) e [editar rascunho](editar-rascunho-390.png). As [verificações e limitações](../VALIDATION.md) explicam o alcance dos testes.
