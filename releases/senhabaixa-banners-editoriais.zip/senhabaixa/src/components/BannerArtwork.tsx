import { BANNER_SCENES } from "@/lib/bannerScenes";

/** A single printed-art collection; each cell is framed without distorting it. */
export function BannerArtwork({
  image,
  className,
  priority = false,
}: {
  image: string;
  className: string;
  priority?: boolean;
}) {
  const stem = image.replace("/art/cat-", "").replace(".svg", "");
  const scene = BANNER_SCENES[stem];
  const sheet = scene
    ? `/art/editorial-scenes-${String(scene.sheet).padStart(2, "0")}.png`
    : undefined;

  return (
    <span
      className={`${className} sb-art-scene`}
      data-artwork={stem}
      data-editorial-family={scene ? "printed-cats" : undefined}
      aria-hidden="true"
    >
      <img
        className="sb-art-background"
        src={scene ? "/art/editorial-ground.svg" : image}
        alt=""
        fetchPriority={priority ? "high" : "auto"}
      />
      {scene && sheet && (
        <>
          <img
            src={sheet}
            alt=""
            hidden
            style={{ display: "none" }}
            fetchPriority={priority ? "high" : "auto"}
          />
          <span
            className="sb-art-subject sb-editorial-subject"
            data-cat-subject=""
            data-scene-cell={`${scene.column},${scene.row}`}
            data-scene-sheet={scene.sheet}
            data-scene-meaning={scene.meaning}
            style={{
              backgroundImage: `url("${sheet}")`,
              backgroundSize: "300% 200%",
              backgroundPosition: `${scene.column * 50}% ${scene.row * 100}%`,
              backgroundRepeat: "no-repeat",
            }}
          />
        </>
      )}
    </span>
  );
}
