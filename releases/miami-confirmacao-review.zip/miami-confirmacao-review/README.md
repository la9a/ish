# Miami — revisão local de confirmação

Este pacote ainda não foi aplicado à VPS. Leia AUDITORIA.md e PROMPT_MIAMI_AUDITORIA.txt antes de usar.

MANIFEST.json identifica o código-base e a proposta por SHA-256. Se o servidor tiver outra versão, adapte os trechos necessários em vez de substituí-lo integralmente. server.patch tem caminhos relativos à raiz do agente.

Validação sem iniciar o serviço e sem conectar contas:

```sh
node --check src/server.mjs
node --test src/opening-update.test.mjs src/admin-update.test.mjs
python3 -m unittest discover -s test -p 'test_*.py' -v
```

O coletor scripts/diagnose.py é somente leitura e exporta métricas selecionadas, sem conteúdo de sessões, credenciais ou linhas brutas de logs. Não reinicie um agente com monitoramentos ativos, não execute outra instância com as mesmas sessões e preserve a configuração e dependências existentes. O benchmark antigo de envio não faz parte deste pacote.
